function calculateFee() {
    var studentType = document.getElementById("studentType").value;
    var residency = document.getElementById("residency").value;
    var credits = parseInt(document.getElementById("credits").value);

    var registrationFee, tuitionRate;

    if (studentType === "bachelor") {
        registrationFee = residency === "in-state" ? 200 : 600;
        tuitionRate = residency === "in-state" ? 350 : 700;
    } else {
        registrationFee = residency === "in-state" ? 300 : 900;
        tuitionRate = residency === "in-state" ? 450 : 900;
    }

    var tuition = credits * tuitionRate;
    var totalFee = registrationFee + tuition;

    document.getElementById("registrationFeeOutput").textContent = "$" + registrationFee;
    document.getElementById("tuitionRateOutput").textContent = "$" + tuitionRate;
    document.getElementById("tuitionOutput").textContent = "$" + tuition;
    document.getElementById("totalFeeOutput").textContent = "$" + totalFee;
}

