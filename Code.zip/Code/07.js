document.addEventListener("DOMContentLoaded", function () {
    // Function to add a student to the table
    function addStudent() {
        const studentId = document.getElementById("student-id").value;
        const studentName = document.getElementById("student-name").value;
        const studentType = document.getElementById("student-type").value;
        const studentResidency = document.getElementById("student-residency").value;
        const studentCredits = document.getElementById("student-credits").value;

        // Create a new row for the student in the table
        const table = document.getElementById("student-list");
        const newRow = table.insertRow(-1); // -1 to append at the end

        // Insert data into the row
        newRow.insertCell(0).textContent = studentId;
        newRow.insertCell(1).textContent = studentName;
        newRow.insertCell(2).textContent = studentType;
        newRow.insertCell(3).textContent = studentResidency;
        newRow.insertCell(4).textContent = studentCredits;

        // Add Edit and Delete buttons
        const editButton = document.createElement("button");
        editButton.textContent = "Edit";
        editButton.onclick = function () {
            editStudent(newRow);
        };
        newRow.insertCell(5).appendChild(editButton);

        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.onclick = function () {
            table.deleteRow(newRow.rowIndex);
        };
        newRow.insertCell(6).appendChild(deleteButton);

        // Clear the form
        document.getElementById("student-form").reset();
    }

    // Function to edit a student's information
    function editStudent(row) {
        const cells = row.cells;
        const studentId = cells[0].textContent;
        const studentName = cells[1].textContent;
        const studentType = cells[2].textContent;
        const studentResidency = cells[3].textContent;
        const studentCredits = cells[4].textContent;

        document.getElementById("student-id").value = studentId;
        document.getElementById("student-name").value = studentName;
        document.getElementById("student-type").value = studentType;
        document.getElementById("student-residency").value = studentResidency;
        document.getElementById("student-credits").value = studentCredits;

        // Remove the row from the table
        row.parentNode.removeChild(row);

        // Change the "Add Student" button to "Save Changes"
        const addButton = document.getElementById("add-student");
        addButton.textContent = "Save Changes";
        addButton.onclick = function () {
            saveChanges(row);
        };
    }

    // Function to save changes after editing
    function saveChanges(row) {
        const studentId = document.getElementById("student-id").value;
        const studentName = document.getElementById("student-name").value;
        const studentType = document.getElementById("student-type").value;
        const studentResidency = document.getElementById("student-residency").value;
        const studentCredits = document.getElementById("student-credits").value;

        // Update the row with the edited information
        const cells = row.cells;
        cells[0].textContent = studentId;
        cells[1].textContent = studentName;
        cells[2].textContent = studentType;
        cells[3].textContent = studentResidency;
        cells[4].textContent = studentCredits;

        // Reset the form and change the button back to "Add Student"
        document.getElementById("student-form").reset();
        const addButton = document.getElementById("add-student");
        addButton.textContent = "Add Student";
        addButton.onclick = addStudent;
    }

    // Add student when the "Add Student" button is clicked
    document.getElementById("add-student").addEventListener("click", addStudent);
});